    // Insert JSON format is database from SFA
    router.get('/insertion3', (req, res) => {
        var collection;
    connection((db) => {
        collection = db.collection('productsmanutan');
         //console.log(collection);
    });
    //console.log(collection);
   
    var fs = require('fs');
    fs.readFile('uploads/step-XML-V0.1 - 1 SFA.xml', (err, data) => {
        if (err) throw err;
        // var json = JSON.parse(data);
        var parser = new xml2js.Parser({ attrkey: 'attribut' });
        parser.parseString(data, function (err, result) {
            // res.json(result);
            console.log("=>",result, "<="); 
            var last = 0;
            var products = result['STEP-ProductInformation']['Products'];
            // suppression des données dans la collection productsmanutan
            connection((db) => {
               db.collection('productsmanutan').deleteMany({}); 
            });
            //insertion des product avec item product par product
            products.forEach((item) => {
                
                connection((db) => {
                    db.collection('productsmanutan').insert(item['Product'], {safe: true});
                });
            });                    
        
        if(err) throw err;
            
        });
            res.json("file inserted ");
      });
    });